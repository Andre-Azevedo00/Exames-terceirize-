import { useState, useEffect } from "react";
import {
  LogIn, LogOut, Plus, FileText, FileSpreadsheet,
  ClipboardList, Search, X, Trash2, ShieldCheck, User as UserIcon
} from "lucide-react";

interface UserAccount {
  username: string;
  password: string;
  role: "admin" | "user";
  displayName: string;
}

interface Exam {
  id: string;
  nome: string;
  cpf: string;
  dataRealizacao: string;
  tipoExame: string;
  local: string;
  departamento: string;
  criadoEm: string;
  criadoPor: string;
}

const DEFAULT_USERS: UserAccount[] = [
  { username: "admin", password: "admin123", role: "admin", displayName: "Administrador" },
  { username: "rh", password: "rh2024", role: "user", displayName: "RH Operacional" },
];

function loadUsers(): UserAccount[] {
  const saved = localStorage.getItem("gestexame_users");
  if (saved) return JSON.parse(saved);
  localStorage.setItem("gestexame_users", JSON.stringify(DEFAULT_USERS));
  return DEFAULT_USERS;
}

function saveUsers(users: UserAccount[]) {
  localStorage.setItem("gestexame_users", JSON.stringify(users));
}

const TIPOS_EXAME = [
  { value: "admissional", label: "Admissional" },
  { value: "demissional", label: "Demissional" },
  { value: "periodico", label: "Periódico" },
  { value: "retorno", label: "Retorno ao Trabalho" },
];

const LOCAIS = [
  { value: "facilita", label: "Facilita" },
  { value: "sidconvenios", label: "SidConvênios" },
];

const DEPARTAMENTOS = ["21", "58", "71", "84", "86", "90", "91", "92"];

const TIPO_COLORS: Record<string, string> = {
  admissional: "bg-emerald-100 text-emerald-800 border-emerald-200",
  demissional: "bg-red-100 text-red-800 border-red-200",
  periodico: "bg-blue-100 text-blue-800 border-blue-200",
  retorno: "bg-amber-100 text-amber-800 border-amber-200",
};

function formatCPF(value: string) {
  const nums = value.replace(/\D/g, "").slice(0, 11);
  return nums
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
}

function formatDateBR(iso: string) {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

function exportCSV(exams: Exam[]) {
  const headers = ["Nome", "CPF", "Data Realização", "Tipo Exame", "Local", "Departamento", "Registrado Em", "Registrado Por"];
  const rows = exams.map((e) => [
    e.nome,
    e.cpf,
    formatDateBR(e.dataRealizacao),
    TIPOS_EXAME.find((t) => t.value === e.tipoExame)?.label ?? e.tipoExame,
    LOCAIS.find((l) => l.value === e.local)?.label ?? e.local,
    e.departamento,
    new Date(e.criadoEm).toLocaleString("pt-BR"),
    e.criadoPor,
  ]);
  const csv = [headers, ...rows].map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
  const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `exames_${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function exportPDF(exams: Exam[]) {
  const tipoLabel = (v: string) => TIPOS_EXAME.find((t) => t.value === v)?.label ?? v;
  const localLabel = (v: string) => LOCAIS.find((l) => l.value === v)?.label ?? v;

  const rows = exams
    .map(
      (e) => `
      <tr>
        <td>${e.nome}</td>
        <td style="font-family:monospace">${e.cpf}</td>
        <td>${formatDateBR(e.dataRealizacao)}</td>
        <td>${tipoLabel(e.tipoExame)}</td>
        <td>${localLabel(e.local)}</td>
        <td>${e.departamento}</td>
        <td>${e.criadoPor}</td>
      </tr>`
    )
    .join("");

  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8">
    <title>Relatório de Exames</title>
    <style>
      body{font-family:Arial,sans-serif;padding:24px;color:#1A2B4A;font-size:13px}
      h1{color:#1A2B4A;font-size:18px;border-bottom:2px solid #0066CC;padding-bottom:8px;margin-bottom:4px}
      .meta{color:#6B7B8D;font-size:11px;margin-bottom:16px}
      table{width:100%;border-collapse:collapse}
      th{background:#1A2B4A;color:#fff;padding:8px 10px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.05em}
      td{padding:7px 10px;border-bottom:1px solid #E8EDF2;vertical-align:top}
      tr:nth-child(even) td{background:#F8F9FB}
    </style>
    </head><body>
    <h1>Relatório de Exames Médicos Ocupacionais</h1>
    <p class="meta">Gerado em: ${new Date().toLocaleString("pt-BR")} &nbsp;|&nbsp; Total: ${exams.length} registro(s)</p>
    <table><thead><tr>
      <th>Nome</th><th>CPF</th><th>Data</th><th>Tipo</th><th>Local</th><th>Depto</th><th>Registrado por</th>
    </tr></thead><tbody>${rows}</tbody></table>
    </body></html>`;

  const win = window.open("", "_blank");
  if (win) {
    win.document.write(html);
    win.document.close();
    win.focus();
    setTimeout(() => win.print(), 400);
  }
}

function StatusBadge({ tipo }: { tipo: string }) {
  const label = TIPOS_EXAME.find((t) => t.value === tipo)?.label ?? tipo;
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded border text-xs font-medium font-mono ${TIPO_COLORS[tipo] ?? "bg-gray-100 text-gray-700 border-gray-200"}`}>
      {label}
    </span>
  );
}

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [exams, setExams] = useState<Exam[]>([]);
  const [view, setView] = useState<"list" | "form">("list");
  const [search, setSearch] = useState("");
  const [filterTipo, setFilterTipo] = useState("");
  const [filterDepto, setFilterDepto] = useState("");

  const [users, setUsers] = useState<UserAccount[]>([]);
  const [authScreen, setAuthScreen] = useState<"login" | "register">("login");

  const [loginUser, setLoginUser] = useState("");
  const [loginPass, setLoginPass] = useState("");
  const [loginErr, setLoginErr] = useState("");

  const [regNome, setRegNome] = useState("");
  const [regUser, setRegUser] = useState("");
  const [regPass, setRegPass] = useState("");
  const [regPass2, setRegPass2] = useState("");
  const [regRole, setRegRole] = useState<"admin" | "user">("user");
  const [regErr, setRegErr] = useState("");
  const [regOk, setRegOk] = useState(false);

  const [fNome, setFNome] = useState("");
  const [fCPF, setFCPF] = useState("");
  const [fData, setFData] = useState("");
  const [fTipo, setFTipo] = useState("admissional");
  const [fLocal, setFLocal] = useState("facilita");
  const [fDepto, setFDepto] = useState("21");
  const [fSuccess, setFSuccess] = useState(false);

  useEffect(() => {
    const u = localStorage.getItem("gestexame_user");
    const e = localStorage.getItem("gestexame_exams");
    if (u) setCurrentUser(JSON.parse(u));
    if (e) setExams(JSON.parse(e));
    setUsers(loadUsers());
  }, []);

  function saveExams(updated: Exam[]) {
    setExams(updated);
    localStorage.setItem("gestexame_exams", JSON.stringify(updated));
  }

  function handleLogin() {
    const all = loadUsers();
    const u = all.find((u) => u.username === loginUser && u.password === loginPass);
    if (u) {
      setCurrentUser(u);
      localStorage.setItem("gestexame_user", JSON.stringify(u));
      setLoginErr("");
    } else {
      setLoginErr("Usuário ou senha incorretos.");
    }
  }

  function handleRegister() {
    setRegErr("");
    if (!regNome.trim() || !regUser.trim() || !regPass || !regPass2) {
      setRegErr("Preencha todos os campos."); return;
    }
    if (regPass.length < 6) {
      setRegErr("A senha deve ter no mínimo 6 caracteres."); return;
    }
    if (regPass !== regPass2) {
      setRegErr("As senhas não coincidem."); return;
    }
    const all = loadUsers();
    if (all.find((u) => u.username === regUser.trim())) {
      setRegErr("Este nome de usuário já está em uso."); return;
    }
    const newUser: UserAccount = {
      username: regUser.trim(),
      password: regPass,
      role: regRole,
      displayName: regNome.trim(),
    };
    const updated = [...all, newUser];
    saveUsers(updated);
    setUsers(updated);
    setRegOk(true);
    setTimeout(() => {
      setRegOk(false);
      setRegNome(""); setRegUser(""); setRegPass(""); setRegPass2("");
      setAuthScreen("login");
    }, 1500);
  }

  function handleLogout() {
    setCurrentUser(null);
    localStorage.removeItem("gestexame_user");
    setView("list");
  }

  function handleSubmit() {
    if (!fNome.trim() || !fCPF.trim() || !fData) return;
    const exam: Exam = {
      id: Date.now().toString(),
      nome: fNome.trim(),
      cpf: fCPF,
      dataRealizacao: fData,
      tipoExame: fTipo,
      local: fLocal,
      departamento: fDepto,
      criadoEm: new Date().toISOString(),
      criadoPor: currentUser?.displayName ?? "",
    };
    saveExams([exam, ...exams]);
    setFNome(""); setFCPF(""); setFData("");
    setFTipo("admissional"); setFLocal("facilita"); setFDepto("21");
    setFSuccess(true);
    setTimeout(() => { setFSuccess(false); setView("list"); }, 1400);
  }

  function handleDelete(id: string) {
    saveExams(exams.filter((e) => e.id !== id));
  }

  const filtered = exams.filter((e) => {
    const q = search.toLowerCase();
    const matchQ = !search || e.nome.toLowerCase().includes(q) || e.cpf.includes(q);
    const matchT = !filterTipo || e.tipoExame === filterTipo;
    const matchD = !filterDepto || e.departamento === filterDepto;
    return matchQ && matchT && matchD;
  });

  // ── LOGIN / REGISTER ───────────────────────────────────────────────────────
  if (!currentUser) {
    return (
      <div
        className="min-h-screen flex items-center justify-center p-4"
        style={{ background: "linear-gradient(135deg, #0F1B2D 0%, #1A2B4A 60%, #0F2A50 100%)" }}
      >
        <div className="w-full max-w-sm">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#0066CC] shadow-lg mb-4">
              <ClipboardList className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-white text-2xl font-semibold tracking-tight" style={{ fontFamily: "Inter, sans-serif" }}>
              GestExame
            </h1>
            <p className="text-[#7A8FA8] text-sm mt-1">Sistema de Controle de Exames Ocupacionais</p>
          </div>

          {/* Tabs */}
          <div className="flex rounded-xl bg-white/10 p-1 mb-4">
            <button
              onClick={() => { setAuthScreen("login"); setLoginErr(""); }}
              className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${authScreen === "login" ? "bg-white text-[#1A2B4A] shadow-sm" : "text-[#7A8FA8] hover:text-white"}`}
            >
              Entrar
            </button>
            <button
              onClick={() => { setAuthScreen("register"); setRegErr(""); setRegOk(false); }}
              className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${authScreen === "register" ? "bg-white text-[#1A2B4A] shadow-sm" : "text-[#7A8FA8] hover:text-white"}`}
            >
              Criar conta
            </button>
          </div>

          <div className="bg-white rounded-2xl p-7 shadow-2xl">

            {/* ── LOGIN FORM ── */}
            {authScreen === "login" && (
              <>
                <h2 className="text-[#1A2B4A] text-base font-semibold mb-5">Acesso ao sistema</h2>
                <div className="space-y-4">
                  <div>
                    <label className="text-[#1A2B4A] text-sm font-medium block mb-1.5">Usuário</label>
                    <input
                      type="text"
                      value={loginUser}
                      onChange={(e) => setLoginUser(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                      placeholder="Digite seu usuário"
                      className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm text-[#1A2B4A] focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all placeholder-[#9BAABB]"
                    />
                  </div>
                  <div>
                    <label className="text-[#1A2B4A] text-sm font-medium block mb-1.5">Senha</label>
                    <input
                      type="password"
                      value={loginPass}
                      onChange={(e) => setLoginPass(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                      placeholder="Digite sua senha"
                      className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm text-[#1A2B4A] focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all placeholder-[#9BAABB]"
                    />
                  </div>
                  {loginErr && <p className="text-red-600 text-sm font-medium">{loginErr}</p>}
                  <button
                    onClick={handleLogin}
                    className="w-full bg-[#0066CC] text-white py-2.5 rounded-lg font-medium text-sm hover:bg-[#0055AA] active:scale-[0.99] transition-all flex items-center justify-center gap-2 shadow-sm"
                  >
                    <LogIn className="w-4 h-4" />
                    Entrar
                  </button>
                </div>
                <div className="mt-5 pt-4 border-t border-[#F0F2F5] text-center">
                  <p className="text-[#9BAABB] text-xs">
                    Não tem conta?{" "}
                    <button
                      onClick={() => setAuthScreen("register")}
                      className="text-[#0066CC] font-medium hover:underline"
                    >
                      Criar conta
                    </button>
                  </p>
                </div>
              </>
            )}

            {/* ── REGISTER FORM ── */}
            {authScreen === "register" && (
              <>
                <h2 className="text-[#1A2B4A] text-base font-semibold mb-5">Criar nova conta</h2>

                {regOk && (
                  <div className="mb-4 bg-emerald-50 border border-emerald-200 rounded-lg px-4 py-3 text-emerald-800 text-sm font-medium flex items-center gap-2">
                    <span>✓</span> Conta criada! Redirecionando para o login...
                  </div>
                )}

                <div className="space-y-4">
                  <div>
                    <label className="text-[#1A2B4A] text-sm font-medium block mb-1.5">Nome completo</label>
                    <input
                      type="text"
                      value={regNome}
                      onChange={(e) => setRegNome(e.target.value)}
                      placeholder="Seu nome"
                      className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm text-[#1A2B4A] focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all placeholder-[#9BAABB]"
                    />
                  </div>
                  <div>
                    <label className="text-[#1A2B4A] text-sm font-medium block mb-1.5">Nome de usuário</label>
                    <input
                      type="text"
                      value={regUser}
                      onChange={(e) => setRegUser(e.target.value.replace(/\s/g, ""))}
                      placeholder="Sem espaços"
                      className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm font-mono text-[#1A2B4A] focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all placeholder-[#9BAABB]"
                    />
                  </div>
                  <div>
                    <label className="text-[#1A2B4A] text-sm font-medium block mb-1.5">Tipo de acesso</label>
                    <select
                      value={regRole}
                      onChange={(e) => setRegRole(e.target.value as "admin" | "user")}
                      className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm text-[#1A2B4A] bg-white focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all"
                    >
                      <option value="user">Usuário (acesso operacional)</option>
                      <option value="admin">Administrador (acesso total + exportação)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[#1A2B4A] text-sm font-medium block mb-1.5">Senha <span className="text-[#9BAABB] font-normal">(mín. 6 caracteres)</span></label>
                    <input
                      type="password"
                      value={regPass}
                      onChange={(e) => setRegPass(e.target.value)}
                      placeholder="Crie uma senha"
                      className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm text-[#1A2B4A] focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all placeholder-[#9BAABB]"
                    />
                  </div>
                  <div>
                    <label className="text-[#1A2B4A] text-sm font-medium block mb-1.5">Confirmar senha</label>
                    <input
                      type="password"
                      value={regPass2}
                      onChange={(e) => setRegPass2(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleRegister()}
                      placeholder="Repita a senha"
                      className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm text-[#1A2B4A] focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all placeholder-[#9BAABB]"
                    />
                  </div>

                  {regErr && <p className="text-red-600 text-sm font-medium">{regErr}</p>}

                  <button
                    onClick={handleRegister}
                    className="w-full bg-[#0066CC] text-white py-2.5 rounded-lg font-medium text-sm hover:bg-[#0055AA] active:scale-[0.99] transition-all flex items-center justify-center gap-2 shadow-sm"
                  >
                    <UserIcon className="w-4 h-4" />
                    Criar conta
                  </button>
                </div>

                <div className="mt-5 pt-4 border-t border-[#F0F2F5] text-center">
                  <p className="text-[#9BAABB] text-xs">
                    Já tem conta?{" "}
                    <button
                      onClick={() => setAuthScreen("login")}
                      className="text-[#0066CC] font-medium hover:underline"
                    >
                      Entrar
                    </button>
                  </p>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ── APP ────────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-[#F0F2F5]" style={{ fontFamily: "Inter, sans-serif" }}>
      {/* Header */}
      <header style={{ background: "#1A2B4A" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#0066CC] flex items-center justify-center flex-shrink-0">
                <ClipboardList className="w-4 h-4 text-white" />
              </div>
              <span className="font-semibold text-white text-sm tracking-tight">GestExame</span>
              <span className="text-[#4A6A8A] text-xs hidden sm:inline ml-1">— Exames Ocupacionais</span>
            </div>

            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center gap-1.5 text-xs text-[#7A8FA8]">
                {currentUser.role === "admin"
                  ? <ShieldCheck className="w-3.5 h-3.5 text-[#0099FF]" />
                  : <UserIcon className="w-3.5 h-3.5" />}
                <span>{currentUser.displayName}</span>
                {currentUser.role === "admin" && (
                  <span className="text-[#0099FF] font-medium">Admin</span>
                )}
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center gap-1.5 text-xs text-[#7A8FA8] hover:text-white transition-colors px-2 py-1.5 rounded-lg hover:bg-white/10"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sair</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {/* Page header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
          <div>
            <h1 className="text-[#1A2B4A] text-xl font-semibold">
              {view === "list" ? "Registros de Exames" : "Novo Registro de Exame"}
            </h1>
            <p className="text-[#6B7B8D] text-sm mt-0.5">
              {view === "list"
                ? `${filtered.length} de ${exams.length} registro(s)`
                : "Preencha os dados do colaborador"}
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {view === "list" && currentUser.role === "admin" && exams.length > 0 && (
              <>
                <button
                  onClick={() => exportCSV(filtered)}
                  className="flex items-center gap-1.5 text-sm px-3 py-2 rounded-lg border border-[#D0D8E4] bg-white text-[#1A2B4A] hover:bg-[#F0F2F5] transition-colors"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  <span>Excel / CSV</span>
                </button>
                <button
                  onClick={() => exportPDF(filtered)}
                  className="flex items-center gap-1.5 text-sm px-3 py-2 rounded-lg border border-[#D0D8E4] bg-white text-[#1A2B4A] hover:bg-[#F0F2F5] transition-colors"
                >
                  <FileText className="w-4 h-4 text-red-500" />
                  <span>PDF</span>
                </button>
              </>
            )}

            {view === "list" ? (
              <button
                onClick={() => setView("form")}
                className="flex items-center gap-1.5 text-sm px-4 py-2 rounded-lg bg-[#0066CC] text-white hover:bg-[#0055AA] transition-colors font-medium shadow-sm"
              >
                <Plus className="w-4 h-4" />
                Novo Exame
              </button>
            ) : (
              <button
                onClick={() => setView("list")}
                className="flex items-center gap-1.5 text-sm px-3 py-2 rounded-lg border border-[#D0D8E4] bg-white text-[#1A2B4A] hover:bg-[#F0F2F5] transition-colors"
              >
                <X className="w-4 h-4" />
                Cancelar
              </button>
            )}
          </div>
        </div>

        {/* ── LIST VIEW ── */}
        {view === "list" && (
          <>
            {/* Filters */}
            <div className="bg-white rounded-xl border border-[#D0D8E4] px-4 py-3 mb-4 flex flex-col sm:flex-row gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9BAABB]" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Buscar por nome ou CPF..."
                  className="w-full pl-9 pr-3 py-2 text-sm border border-[#D0D8E4] rounded-lg text-[#1A2B4A] placeholder-[#9BAABB] focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all"
                />
              </div>
              <select
                value={filterTipo}
                onChange={(e) => setFilterTipo(e.target.value)}
                className="text-sm border border-[#D0D8E4] rounded-lg px-3 py-2 text-[#1A2B4A] bg-white focus:outline-none focus:border-[#0066CC] transition-all"
              >
                <option value="">Todos os tipos</option>
                {TIPOS_EXAME.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
              <select
                value={filterDepto}
                onChange={(e) => setFilterDepto(e.target.value)}
                className="text-sm border border-[#D0D8E4] rounded-lg px-3 py-2 text-[#1A2B4A] bg-white focus:outline-none focus:border-[#0066CC] transition-all"
              >
                <option value="">Todos os departamentos</option>
                {DEPARTAMENTOS.map((d) => (
                  <option key={d} value={d}>Departamento {d}</option>
                ))}
              </select>
            </div>

            {/* Stats row */}
            {exams.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                {TIPOS_EXAME.map((t) => {
                  const count = exams.filter((e) => e.tipoExame === t.value).length;
                  return (
                    <div key={t.value} className="bg-white rounded-xl border border-[#D0D8E4] px-4 py-3">
                      <p className="text-[#9BAABB] text-xs uppercase tracking-wider font-medium">{t.label}</p>
                      <p className="text-[#1A2B4A] text-2xl font-semibold mt-1" style={{ fontFamily: "DM Mono, monospace" }}>{count}</p>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Table */}
            {filtered.length === 0 ? (
              <div className="bg-white rounded-xl border border-[#D0D8E4] py-16 text-center">
                <ClipboardList className="w-10 h-10 text-[#D0D8E4] mx-auto mb-3" />
                <p className="text-[#6B7B8D] text-sm font-medium">
                  {exams.length === 0 ? "Nenhum exame registrado ainda." : "Nenhum resultado para os filtros aplicados."}
                </p>
                {exams.length === 0 && (
                  <button
                    onClick={() => setView("form")}
                    className="mt-3 text-sm text-[#0066CC] hover:underline"
                  >
                    Registrar o primeiro exame →
                  </button>
                )}
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-[#D0D8E4] overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-[#F8F9FB] border-b border-[#E8EDF2]">
                        <th className="text-left px-4 py-3 text-xs font-semibold text-[#9BAABB] uppercase tracking-wider whitespace-nowrap">Colaborador</th>
                        <th className="text-left px-4 py-3 text-xs font-semibold text-[#9BAABB] uppercase tracking-wider whitespace-nowrap">CPF</th>
                        <th className="text-left px-4 py-3 text-xs font-semibold text-[#9BAABB] uppercase tracking-wider whitespace-nowrap">Data</th>
                        <th className="text-left px-4 py-3 text-xs font-semibold text-[#9BAABB] uppercase tracking-wider whitespace-nowrap">Tipo</th>
                        <th className="text-left px-4 py-3 text-xs font-semibold text-[#9BAABB] uppercase tracking-wider whitespace-nowrap">Local</th>
                        <th className="text-left px-4 py-3 text-xs font-semibold text-[#9BAABB] uppercase tracking-wider whitespace-nowrap">Depto</th>
                        <th className="text-left px-4 py-3 text-xs font-semibold text-[#9BAABB] uppercase tracking-wider whitespace-nowrap hidden md:table-cell">Registrado por</th>
                        {currentUser.role === "admin" && <th className="px-4 py-3 w-10"></th>}
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.map((exam, i) => (
                        <tr
                          key={exam.id}
                          className={`hover:bg-[#F8F9FB] transition-colors ${i < filtered.length - 1 ? "border-b border-[#F0F2F5]" : ""}`}
                        >
                          <td className="px-4 py-3 font-medium text-[#1A2B4A] whitespace-nowrap">{exam.nome}</td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <span className="font-mono text-xs text-[#6B7B8D]">{exam.cpf}</span>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-[#1A2B4A]">
                            {formatDateBR(exam.dataRealizacao)}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <StatusBadge tipo={exam.tipoExame} />
                          </td>
                          <td className="px-4 py-3 text-[#6B7B8D] whitespace-nowrap">
                            {LOCAIS.find((l) => l.value === exam.local)?.label}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <span className="font-mono text-xs bg-[#EEF1F5] text-[#1A2B4A] px-2 py-0.5 rounded font-medium">
                              {exam.departamento}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-[#9BAABB] text-xs hidden md:table-cell">
                            {exam.criadoPor}
                          </td>
                          {currentUser.role === "admin" && (
                            <td className="px-4 py-3">
                              <button
                                onClick={() => handleDelete(exam.id)}
                                className="p-1.5 rounded-lg text-[#C0C8D4] hover:text-red-500 hover:bg-red-50 transition-colors"
                                title="Excluir"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}

        {/* ── FORM VIEW ── */}
        {view === "form" && (
          <div className="max-w-2xl">
            {fSuccess && (
              <div className="mb-5 bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 text-emerald-800 text-sm font-medium flex items-center gap-2">
                <span className="text-emerald-500 text-base">✓</span>
                Exame registrado com sucesso! Redirecionando...
              </div>
            )}

            <div className="bg-white rounded-xl border border-[#D0D8E4] p-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">

                {/* Nome */}
                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-[#1A2B4A] mb-1.5">
                    Nome do Colaborador <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={fNome}
                    onChange={(e) => setFNome(e.target.value)}
                    placeholder="Nome completo do colaborador"
                    className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm text-[#1A2B4A] placeholder-[#C0C8D4] focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all"
                  />
                </div>

                {/* CPF */}
                <div>
                  <label className="block text-sm font-medium text-[#1A2B4A] mb-1.5">
                    CPF <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={fCPF}
                    onChange={(e) => setFCPF(formatCPF(e.target.value))}
                    placeholder="000.000.000-00"
                    maxLength={14}
                    className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm font-mono text-[#1A2B4A] placeholder-[#C0C8D4] focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all"
                  />
                </div>

                {/* Data */}
                <div>
                  <label className="block text-sm font-medium text-[#1A2B4A] mb-1.5">
                    Data de Realização <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={fData}
                    onChange={(e) => setFData(e.target.value)}
                    className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm text-[#1A2B4A] focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all"
                  />
                </div>

                {/* Tipo */}
                <div>
                  <label className="block text-sm font-medium text-[#1A2B4A] mb-1.5">Tipo de Exame</label>
                  <select
                    value={fTipo}
                    onChange={(e) => setFTipo(e.target.value)}
                    className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm text-[#1A2B4A] bg-white focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all"
                  >
                    {TIPOS_EXAME.map((t) => (
                      <option key={t.value} value={t.value}>{t.label}</option>
                    ))}
                  </select>
                </div>

                {/* Local */}
                <div>
                  <label className="block text-sm font-medium text-[#1A2B4A] mb-1.5">Local de Realização</label>
                  <select
                    value={fLocal}
                    onChange={(e) => setFLocal(e.target.value)}
                    className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm text-[#1A2B4A] bg-white focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all"
                  >
                    {LOCAIS.map((l) => (
                      <option key={l.value} value={l.value}>{l.label}</option>
                    ))}
                  </select>
                </div>

                {/* Departamento */}
                <div>
                  <label className="block text-sm font-medium text-[#1A2B4A] mb-1.5">Departamento</label>
                  <select
                    value={fDepto}
                    onChange={(e) => setFDepto(e.target.value)}
                    className="w-full border border-[#D0D8E4] rounded-lg px-3 py-2.5 text-sm text-[#1A2B4A] bg-white focus:outline-none focus:border-[#0066CC] focus:ring-2 focus:ring-[#0066CC]/20 transition-all"
                  >
                    {DEPARTAMENTOS.map((d) => (
                      <option key={d} value={d}>Departamento {d}</option>
                    ))}
                  </select>
                </div>

              </div>

              {/* Divider + actions */}
              <div className="mt-6 pt-5 border-t border-[#F0F2F5] flex items-center gap-3">
                <button
                  onClick={handleSubmit}
                  disabled={!fNome.trim() || !fCPF.trim() || !fData}
                  className="px-6 py-2.5 bg-[#0066CC] text-white rounded-lg text-sm font-medium hover:bg-[#0055AA] disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-sm active:scale-[0.99]"
                >
                  Salvar Registro
                </button>
                <button
                  onClick={() => setView("list")}
                  className="px-4 py-2.5 border border-[#D0D8E4] text-[#1A2B4A] rounded-lg text-sm hover:bg-[#F0F2F5] transition-colors"
                >
                  Cancelar
                </button>
                <span className="text-[#9BAABB] text-xs ml-auto">
                  <span className="text-red-400">*</span> Campos obrigatórios
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
