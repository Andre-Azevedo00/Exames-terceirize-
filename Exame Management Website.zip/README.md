
  # Exame Management Website

  This is a code bundle for Exame Management Website. The original project is available at https://www.figma.com/design/B3Bnc7CaEJhRGfB7ZrMm4r/Exame-Management-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  